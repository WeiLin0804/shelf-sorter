/*
 * This file is part of Playgama Bridge.
 *
 * Playgama Bridge is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * Playgama Bridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Playgama Bridge. If not, see <https://www.gnu.org/licenses/>.
 */

import PlatformBridgeBase from './PlatformBridgeBase'
import {
    addJavaScript,
    waitFor,
    type AnyRecord,
} from '../utils'
import type { AdvancedBannerConfig } from '../modules/advertisement'
import type { ScheduledNotification } from '../modules/notifications/types'
import {
    ACTION_NAME,
    LAUNCH_SOURCE,
    BridgeError,
    ERROR_CODE,
    type LaunchSource,
} from '../constants'
import { PLATFORM_ID, type PlatformId } from '../modules/platform/constants'
import {
    BANNER_STATE,
    INTERSTITIAL_STATE,
    REWARDED_STATE,
    BANNER_POSITION,
} from '../modules/advertisement/constants'
import { LEADERBOARD_TYPE, type LeaderboardType } from '../modules/leaderboards/constants'

const SDK_URL = 'https://assets.msn.com/staticsb/statics/latest/msstart-games-sdk/msstart-v1.0.0-rc.21.min.js'
const PLAYGAMA_ADS_SDK_URL = 'https://playgama.com/ads/msn.v0.1.js'

interface MsnNotification {
    title: string
    description: string
    type: number
    imageData?: string
    payload?: string
    minDelayInSeconds?: number
    callToAction?: string
}

const MSN_NOTIFICATION_TITLE_MAX_LENGTH = 60
const MSN_NOTIFICATION_DESCRIPTION_MAX_LENGTH = 200
const MSN_NOTIFICATION_MAX_DELAY_SECONDS = 604800

const AUTO_NOTIFICATIONS: MsnNotification[] = [
    {
        title: 'Ready for another round?',
        description: 'Jump back in right where you left off.',
        type: 8,
        minDelayInSeconds: 86400,
        payload: 'msn_auto_24h',
    },
    {
        title: 'Missing your moves',
        description: "It's perfect time to come back",
        type: 9,
        minDelayInSeconds: 259200,
        payload: 'msn_auto_3d',
    },
    {
        title: 'We miss you',
        description: 'Seriously. Come play.',
        type: 10,
        minDelayInSeconds: 604800,
        payload: 'msn_auto_7d',
    },
]

// Config maps a notification id to the MSN notification type, either as a
// number or as a string when it comes from a text-based config field.
function parseMsnNotificationType(value?: string | number): number | undefined {
    if (typeof value === 'number') {
        return value
    }

    if (typeof value === 'string' && value.trim() !== '') {
        return Number(value)
    }

    return undefined
}

const MSN_SIZES_BY_POSITION: Record<string, [number, number][]> = {
    top: [[728, 90], [970, 250], [320, 50]],
    bottom: [[320, 50]],
    left: [[300, 250], [300, 600], [320, 50], [160, 600]],
    right: [[300, 250], [300, 600], [320, 50], [160, 600]],
    topleft: [[300, 250]],
    topright: [[300, 250]],
    bottomleft: [[300, 250]],
    bottomright: [[300, 250]],
}

// MSN reports an unfulfilled ad request with these codes, only then custom backfill is allowed
const MSN_BACKFILL_ERROR_CODES = ['LOAD_ADS_FAILURE', 'SHOW_ADS_FAILURE']

interface MsnLoadAdsOptions {
    isRewardedAd: boolean
    canBackfill: boolean
}

interface MsnAdInstance {
    instanceId: string
    showAdsCompletedAsync: Promise<unknown>
}

interface MsnIap {
    purchaseAsync(params: { productId: string }): Promise<{
        code?: string
        description?: string
        receipt: AnyRecord
        receiptSignature: string
    }>
    consumeAsync(params: { productId: string }): Promise<{
        code?: string
        description?: string
        consumptionReceipt: AnyRecord
        consumptionSignature: string
    }>
    getAllAddOnsAsync(params: { productId: string }): Promise<AnyRecord & { code?: string; description?: string }>
    getAllPurchasesAsync(params: { productId: string }): Promise<{
        receipts: AnyRecord[]
        receiptSignature: string
    }>
}

interface MsnSdk {
    getSignedInUserAsync(): Promise<AnyRecord>
    signInAsync(): Promise<AnyRecord>
    scheduleNotificationAsync(notification: MsnNotification): Promise<unknown>
    getNotificationPayload?(): string | undefined
    cloudSave: {
        saveDataAsync(params: { data: AnyRecord; gameId: unknown }): Promise<unknown>
        getDataAsync(params: { gameId: unknown }): Promise<AnyRecord>
    }
    shareAsync(options: unknown): Promise<unknown>
    promptInstallAsync(): Promise<string>
    submitGameResultsAsync(score: unknown): Promise<unknown>
    showDisplayAdsAsync(placements: string[]): Promise<unknown>
    hideDisplayAdsAsync(): Promise<unknown>
    loadAdsAsync(options: MsnLoadAdsOptions): Promise<MsnAdInstance>
    showAdsAsync(instanceId: string): Promise<MsnAdInstance>
    iap: MsnIap
}

interface PgAdInstance {
    state: string
    show(): void
    addEventListener(event: string, callback: () => void): void
}

interface PgAdsSdk {
    init(id: string): Promise<unknown>
    updateTargeting(targeting: Record<string, unknown>): void
    requestOutOfPageAd(type: string): Promise<PgAdInstance>
}

declare global {
    interface Window {
        $msstart?: MsnSdk
    }
}

class MsnPlatformBridge extends PlatformBridgeBase {
    // platform
    get platformId(): PlatformId {
        return PLATFORM_ID.MSN
    }

    get launchSource(): LaunchSource | null {
        if (new URLSearchParams(window.location.search).has('notificationPayload')) {
            return LAUNCH_SOURCE.NOTIFICATION
        }

        return super.launchSource
    }

    // advertisement
    get isInterstitialSupported(): boolean {
        return true
    }

    get isRewardedSupported(): boolean {
        return true
    }

    // player
    get isPlayerAuthorizationSupported(): boolean {
        return true
    }

    // social
    get isShareSupported(): boolean {
        return true
    }

    get isAddToHomeScreenSupported(): boolean {
        const sdk = this._platformSdk as MsnSdk | null
        return typeof sdk?.promptInstallAsync === 'function'
    }

    // leaderboards
    get leaderboardsType(): LeaderboardType {
        return LEADERBOARD_TYPE.NATIVE
    }

    // advertisement
    get isBannerSupported(): boolean {
        return true
    }

    // payments
    get isPaymentsSupported(): boolean {
        return this.#isPaymentsSupported
    }

    // notifications
    get isNotificationsSupported(): boolean {
        return true
    }

    // When the game is launched from a notification, its payload is delivered
    // as the regular platform payload.
    get platformPayload(): string | null {
        const sdk = this._platformSdk as MsnSdk | null
        if (typeof sdk?.getNotificationPayload === 'function') {
            const payload = sdk.getNotificationPayload()
            if (payload) {
                return payload
            }
        }

        return super.platformPayload
    }

    // storage
    protected _isAdvancedBannersSupported = true

    #playgamaAds: PgAdsSdk | null = null

    #isPaymentsSupported = false

    initialize(): Promise<unknown> {
        if (this._isInitialized) {
            return Promise.resolve()
        }

        let promiseDecorator = this._getPromiseDecorator(ACTION_NAME.INITIALIZE)
        if (!promiseDecorator) {
            promiseDecorator = this._createPromiseDecorator(ACTION_NAME.INITIALIZE)

            addJavaScript(SDK_URL)
                .then(() => waitFor('$msstart'))
                .then(() => {
                    this._platformSdk = window.$msstart as MsnSdk

                    if (this._options?.disableAutoNotifications !== true) {
                        AUTO_NOTIFICATIONS.forEach((notification) => {
                            (this._platformSdk as MsnSdk).scheduleNotificationAsync(notification).catch(() => {})
                        })
                    }

                    (this._platformSdk as MsnSdk).getSignedInUserAsync()
                        .then((data) => {
                            this.#updatePlayerInfo(data)
                        })
                        .catch(() => {
                            this.#updatePlayerInfo(null)
                        })
                        .finally(() => {
                            this._setPlatformStorageAvailable(this._isPlayerAuthorized)

                            this._isInitialized = true
                            this._resolvePromiseDecorator(ACTION_NAME.INITIALIZE)
                        })
                })

            const advertisementOptions = this._options?.advertisement as AnyRecord | undefined
            const advertisementBackfillId = advertisementOptions?.backfillId as string | undefined
            if (advertisementBackfillId) {
                addJavaScript(PLAYGAMA_ADS_SDK_URL)
                    .then(() => waitFor('pgAds'))
                    .then(() => {
                        const { pgAds } = (window as unknown as { pgAds?: PgAdsSdk })
                        if (!pgAds) {
                            return
                        }
                        pgAds.init(advertisementBackfillId)
                            .then(() => {
                                this.#playgamaAds = pgAds
                                const gameId = this._options.gameId as string
                                this.#playgamaAds.updateTargeting({ gameId })
                            })
                    })
            }
        }

        return promiseDecorator.promise
    }

    // player
    authorizePlayer(): Promise<unknown> {
        if (this._isPlayerAuthorized) {
            return Promise.resolve()
        }

        return new Promise((resolve, reject) => {
            (this._platformSdk as MsnSdk).signInAsync()
                .then((response) => {
                    this.#updatePlayerInfo(response)
                    resolve(undefined)
                })
                .catch((e) => {
                    this.#updatePlayerInfo(null)
                    reject(e)
                })
        })
    }

    // storage
    getDataFromStorage(): Promise<Record<string, unknown>> {
        return (this._platformSdk as MsnSdk).cloudSave
            .getDataAsync({ gameId: this._options.gameId }) as Promise<Record<string, unknown>>
    }

    async setDataToStorage(data: Record<string, unknown>): Promise<void> {
        const snapshot = await (this._platformSdk as MsnSdk).cloudSave
            .getDataAsync({ gameId: this._options.gameId }) as Record<string, unknown>
        Object.keys(data).forEach((key) => { snapshot[key] = data[key] })
        await (this._platformSdk as MsnSdk).cloudSave.saveDataAsync({
            data: snapshot,
            gameId: this._options.gameId,
        })
    }

    async deleteDataFromStorage(keys: string[]): Promise<void> {
        const snapshot = await (this._platformSdk as MsnSdk).cloudSave
            .getDataAsync({ gameId: this._options.gameId }) as Record<string, unknown>
        keys.forEach((key) => { snapshot[key] = null })
        await (this._platformSdk as MsnSdk).cloudSave.saveDataAsync({
            data: snapshot,
            gameId: this._options.gameId,
        })
    }

    // social
    share(options?: unknown): Promise<unknown> {
        // MSN forwards the whole options object to shareAsync as-is.
        return new Promise((resolve, reject) => {
            (this._platformSdk as MsnSdk).shareAsync(options)
                .then(resolve)
                .catch(reject)
        })
    }

    addToHomeScreen(): Promise<unknown> {
        let promiseDecorator = this._getPromiseDecorator(ACTION_NAME.ADD_TO_HOME_SCREEN)
        if (!promiseDecorator) {
            promiseDecorator = this._createPromiseDecorator(ACTION_NAME.ADD_TO_HOME_SCREEN);
            (this._platformSdk as MsnSdk).promptInstallAsync()
                .then((outcome) => {
                    if (outcome === 'accepted') {
                        this._resolvePromiseDecorator(ACTION_NAME.ADD_TO_HOME_SCREEN)
                        return
                    }

                    this._rejectPromiseDecorator(ACTION_NAME.ADD_TO_HOME_SCREEN)
                })
                .catch((error) => {
                    this._rejectPromiseDecorator(ACTION_NAME.ADD_TO_HOME_SCREEN, error)
                })
        }

        return promiseDecorator.promise
    }

    // leaderboards
    leaderboardsSetScore(_id?: unknown, score?: unknown): Promise<unknown> {
        return new Promise((resolve, reject) => {
            (this._platformSdk as MsnSdk).submitGameResultsAsync(score)
                .then(resolve)
                .catch(reject)
        })
    }

    // notifications
    notificationsSchedule(
        notification: ScheduledNotification,
        platformValue?: string | number,
    ): Promise<unknown> {
        const type = parseMsnNotificationType(platformValue)

        const validationError = this.#validateMsnNotification(notification, type)
        if (validationError) {
            return Promise.reject(new BridgeError(ERROR_CODE.NOTIFICATION_INVALID_PARAMETERS, validationError))
        }

        const msnNotification: MsnNotification = {
            title: notification.title,
            description: notification.description,
            type: type as number,
        }

        if (notification.image !== undefined) {
            msnNotification.imageData = notification.image
        }
        if (notification.payload !== undefined) {
            msnNotification.payload = notification.payload
        }
        if (notification.delaySeconds !== undefined) {
            msnNotification.minDelayInSeconds = notification.delaySeconds
        }
        if (notification.callToAction !== undefined) {
            msnNotification.callToAction = notification.callToAction
        }

        return (this._platformSdk as MsnSdk).scheduleNotificationAsync(msnNotification)
    }

    // advertisement
    showBanner(position?: unknown): void {
        let size: string

        switch (position) {
            case BANNER_POSITION.TOP:
                size = 'top:728x90'
                break
            case BANNER_POSITION.BOTTOM:
            default:
                size = 'bottom:320x50'
                break
        }

        (this._platformSdk as MsnSdk).showDisplayAdsAsync([size])
            .then(() => {
                this._setBannerState(BANNER_STATE.SHOWN)
            })
            .catch(() => {
                this._setBannerState(BANNER_STATE.FAILED)
            })
    }

    hideBanner(): void {
        (this._platformSdk as MsnSdk).hideDisplayAdsAsync()
            .then(() => {
                this._setBannerState(BANNER_STATE.HIDDEN)
            })
    }

    showAdvancedBanners(banners?: unknown): void {
        this._setAdvancedBannersState(BANNER_STATE.LOADING)

        const bannersList = (banners as AdvancedBannerConfig[] | undefined) ?? []
        const placements = [...new Set(
            bannersList
                .map((banner) => this.#bannerToMsnPlacement(banner))
                .filter((p): p is string => Boolean(p)),
        )].slice(0, 2)

        if (placements.length === 0) {
            this._setAdvancedBannersState(BANNER_STATE.FAILED)
            return
        }

        (this._platformSdk as MsnSdk).showDisplayAdsAsync(placements)
            .then(() => {
                this._setAdvancedBannersState(BANNER_STATE.SHOWN)
            })
            .catch(() => {
                this._setAdvancedBannersState(BANNER_STATE.FAILED)
            })
    }

    hideAdvancedBanners(): void {
        (this._platformSdk as MsnSdk).hideDisplayAdsAsync()
            .then(() => {
                this._setAdvancedBannersState(BANNER_STATE.HIDDEN)
            })
    }

    showInterstitial(): void {
        const sdk = this._platformSdk as MsnSdk
        sdk.loadAdsAsync({ isRewardedAd: false, canBackfill: this.#playgamaAds !== null })
            .then((adInstance) => sdk.showAdsAsync(adInstance.instanceId))
            .then((adInstance) => {
                this._setInterstitialState(INTERSTITIAL_STATE.OPENED)
                return adInstance.showAdsCompletedAsync
                    .catch(() => {})
                    .then(() => this._setInterstitialState(INTERSTITIAL_STATE.CLOSED))
            }, (error) => this.#handleAdFailure(error, false))
    }

    showRewarded(): void {
        const sdk = this._platformSdk as MsnSdk
        sdk.loadAdsAsync({ isRewardedAd: true, canBackfill: this.#playgamaAds !== null })
            .then((adInstance) => sdk.showAdsAsync(adInstance.instanceId))
            .then((adInstance) => {
                this._setRewardedState(REWARDED_STATE.OPENED)
                return adInstance.showAdsCompletedAsync
                    .then(() => this._setRewardedState(REWARDED_STATE.REWARDED))
                    // Skipped or closed before completion, no reward
                    .catch(() => {})
                    .then(() => this._setRewardedState(REWARDED_STATE.CLOSED))
            }, (error) => this.#handleAdFailure(error, true))
    }

    // payments
    async paymentsPurchase(id: string): Promise<unknown> {
        const product = this._paymentsGetProductPlatformData(id)
        if (!product) {
            return Promise.reject()
        }

        let promiseDecorator = this._getPromiseDecorator(ACTION_NAME.PURCHASE)
        if (!promiseDecorator) {
            promiseDecorator = this._createPromiseDecorator(ACTION_NAME.PURCHASE)

            try {
                if (!this._isPlayerAuthorized) {
                    await this.authorizePlayer()
                }

                const purchase = await (this._platformSdk as MsnSdk).iap.purchaseAsync({
                    productId: product.platformProductId as string,
                })

                if (purchase.code === 'IAP_PURCHASE_FAILURE') {
                    throw new Error(purchase.description)
                }

                const mergedPurchase = {
                    id,
                    ...purchase.receipt,
                    receiptSignature: purchase.receiptSignature,
                }

                this._paymentsPurchases.push(mergedPurchase)
                this._resolvePromiseDecorator(ACTION_NAME.PURCHASE, mergedPurchase)
            } catch (e) {
                this._rejectPromiseDecorator(ACTION_NAME.PURCHASE, e)
            }
        }

        return promiseDecorator.promise
    }

    async paymentsConsumePurchase(id: string): Promise<unknown> {
        const purchaseIndex = this._paymentsPurchases.findIndex((p) => p.id === id)
        if (purchaseIndex < 0) {
            return Promise.reject()
        }

        let promiseDecorator = this._getPromiseDecorator(ACTION_NAME.CONSUME_PURCHASE)
        if (!promiseDecorator) {
            promiseDecorator = this._createPromiseDecorator(ACTION_NAME.CONSUME_PURCHASE)

            try {
                if (!this._isPlayerAuthorized) {
                    await this.authorizePlayer()
                }

                const response = await (this._platformSdk as MsnSdk).iap.consumeAsync({
                    productId: this._paymentsPurchases[purchaseIndex].productId as string,
                })

                if (response.code === 'IAP_CONSUME_FAILURE') {
                    throw new Error(response.description)
                }

                this._paymentsPurchases.splice(purchaseIndex, 1)
                const result: AnyRecord = {
                    id,
                    ...response.consumptionReceipt,
                    consumptionSignature: response.consumptionSignature,
                }

                delete result.productId
                this._resolvePromiseDecorator(ACTION_NAME.CONSUME_PURCHASE, result)
            } catch (error) {
                this._rejectPromiseDecorator(ACTION_NAME.CONSUME_PURCHASE, error)
            }
        }
        return promiseDecorator.promise
    }

    paymentsGetCatalog(): Promise<unknown> {
        const products = this._paymentsGetProductsPlatformData()
        if (!products) {
            return Promise.reject()
        }

        let promiseDecorator = this._getPromiseDecorator(ACTION_NAME.GET_CATALOG)
        if (!promiseDecorator) {
            promiseDecorator = this._createPromiseDecorator(ACTION_NAME.GET_CATALOG);
            (this._platformSdk as MsnSdk).iap.getAllAddOnsAsync({ productId: this._options.gameId as string })
                .then((msnProducts) => {
                    if ((msnProducts as AnyRecord).code === 'IAP_GET_ALL_ADD_ONS_FAILURE') {
                        this._rejectPromiseDecorator(ACTION_NAME.GET_CATALOG, (msnProducts as AnyRecord).description)
                        return
                    }

                    const list = msnProducts as unknown as AnyRecord[]
                    const mergedProducts = products.map((product) => {
                        const msnProduct = list
                            .find((p) => p.productId === product.platformProductId) as AnyRecord | undefined
                        const price = (msnProduct?.price as AnyRecord | undefined) ?? {}

                        const listPrice = price.listPrice ?? null
                        const priceCurrencyCode = (price.currencyCode as string | undefined) || null
                        const formattedPrice = listPrice !== null && priceCurrencyCode
                            ? `${listPrice} ${priceCurrencyCode} `
                            : null

                        return {
                            id: product.id,
                            title: msnProduct?.title || null,
                            description: msnProduct?.description || null,
                            publisherName: msnProduct?.publisherName || null,
                            inAppOfferToken: msnProduct?.inAppOfferToken || null,
                            isConsumable: msnProduct?.isConsumable ?? null,
                            price: formattedPrice,
                            priceCurrencyCode,
                            priceValue: listPrice,
                        }
                    })

                    this._resolvePromiseDecorator(ACTION_NAME.GET_CATALOG, mergedProducts)
                })
                .catch((error) => {
                    this._rejectPromiseDecorator(ACTION_NAME.GET_CATALOG, error)
                })
        }

        return promiseDecorator.promise
    }

    async paymentsGetPurchases(): Promise<unknown> {
        let promiseDecorator = this._getPromiseDecorator(ACTION_NAME.GET_PURCHASES)
        if (!promiseDecorator) {
            promiseDecorator = this._createPromiseDecorator(ACTION_NAME.GET_PURCHASES)

            try {
                if (!this._isPlayerAuthorized) {
                    await this.authorizePlayer()
                }

                const response = await (this._platformSdk as MsnSdk).iap.getAllPurchasesAsync({
                    productId: this._options.gameId as string,
                })

                const products = this._paymentsGetProductsPlatformData()
                this._paymentsPurchases = response.receipts.map((purchase) => {
                    const product = products.find((p) => p.platformProductId === purchase.productId)
                    const mergedPurchase = {
                        id: product?.id as string,
                        ...purchase,
                        receiptSignature: response.receiptSignature,
                    }

                    return mergedPurchase
                })

                this._resolvePromiseDecorator(ACTION_NAME.GET_PURCHASES, this._paymentsPurchases)
            } catch (error) {
                if ((error as AnyRecord)?.code === 'IAP_GET_ALL_PURCHASES_FAILURE') {
                    this._resolvePromiseDecorator(ACTION_NAME.GET_PURCHASES, [])
                } else {
                    this._rejectPromiseDecorator(ACTION_NAME.GET_PURCHASES, error)
                }
            }
        }

        return promiseDecorator.promise
    }

    #handleAdFailure(error: unknown, isRewarded: boolean): Promise<void> {
        const code = (error as { code?: string } | undefined)?.code
        if (code && MSN_BACKFILL_ERROR_CODES.includes(code)) {
            return isRewarded ? this.#showPlaygamaRewarded() : this.#showPlaygamaInterstitial()
        }

        return this._advertisementShowErrorPopup(isRewarded)
    }

    #showPlaygamaInterstitial(): Promise<void> {
        if (!this.#playgamaAds) {
            return this._advertisementShowErrorPopup(false)
        }

        return new Promise((resolve) => {
            this.#playgamaAds!.requestOutOfPageAd('interstitial')
                .then((adInstance) => {
                    switch (adInstance.state) {
                        case 'empty':
                            this._advertisementShowErrorPopup(false).then(() => resolve())
                            return
                        case 'ready':
                            this._setInterstitialState(INTERSTITIAL_STATE.OPENED)
                            adInstance.show()
                            break
                        default:
                            break
                    }

                    adInstance.addEventListener('ready', () => {
                        this._setInterstitialState(INTERSTITIAL_STATE.OPENED)
                        adInstance.show()
                    })

                    adInstance.addEventListener('empty', () => {
                        this._advertisementShowErrorPopup(false).then(() => resolve())
                    })

                    adInstance.addEventListener('closed', () => {
                        this._setInterstitialState(INTERSTITIAL_STATE.CLOSED)
                        resolve()
                    })
                })
        })
    }

    #showPlaygamaRewarded(): Promise<void> {
        if (!this.#playgamaAds) {
            return this._advertisementShowErrorPopup(true)
        }

        return new Promise((resolve) => {
            this.#playgamaAds!.requestOutOfPageAd('rewarded')
                .then((adInstance) => {
                    switch (adInstance.state) {
                        case 'empty':
                            this._advertisementShowErrorPopup(true).then(() => resolve())
                            return
                        case 'ready':
                            this._setRewardedState(REWARDED_STATE.OPENED)
                            adInstance.show()
                            break
                        default:
                            break
                    }

                    adInstance.addEventListener('ready', () => {
                        this._setRewardedState(REWARDED_STATE.OPENED)
                        adInstance.show()
                    })

                    adInstance.addEventListener('rewarded', () => {
                        this._setRewardedState(REWARDED_STATE.REWARDED)
                    })

                    adInstance.addEventListener('empty', () => {
                        this._advertisementShowErrorPopup(true).then(() => resolve())
                    })

                    adInstance.addEventListener('closed', () => {
                        this._setRewardedState(REWARDED_STATE.CLOSED)
                        resolve()
                    })
                })
        })
    }

    #validateMsnNotification(notification: ScheduledNotification, type?: number): string | null {
        if (type === undefined || Number.isNaN(type) || !Number.isInteger(type) || type < 0 || type > 15) {
            return `Notification "${notification.id}" must be mapped to an integer MSN type (0-15) in the "notifications" config section`
        }

        if (this._options?.disableAutoNotifications !== true
            && AUTO_NOTIFICATIONS.some((autoNotification) => autoNotification.type === type)) {
            const reservedTypes = AUTO_NOTIFICATIONS.map((autoNotification) => autoNotification.type).join(', ')
            return `MSN types ${reservedTypes} are reserved for built-in auto notifications; set "disableAutoNotifications": true to use them`
        }

        if (notification.title.length > MSN_NOTIFICATION_TITLE_MAX_LENGTH) {
            return `Notification "title" must be at most ${MSN_NOTIFICATION_TITLE_MAX_LENGTH} characters`
        }

        if (notification.description.length > MSN_NOTIFICATION_DESCRIPTION_MAX_LENGTH) {
            return `Notification "description" must be at most ${MSN_NOTIFICATION_DESCRIPTION_MAX_LENGTH} characters`
        }

        if (notification.delaySeconds !== undefined && notification.delaySeconds > MSN_NOTIFICATION_MAX_DELAY_SECONDS) {
            return `Notification "delaySeconds" must be at most ${MSN_NOTIFICATION_MAX_DELAY_SECONDS} (7 days)`
        }

        return null
    }

    #bannerToMsnPlacement(banner: AdvancedBannerConfig): string | null {
        const position = this.#resolveMsnPosition(banner)
        if (!position) {
            return null
        }

        const sizes = MSN_SIZES_BY_POSITION[position]
        if (!sizes || sizes.length === 0) {
            return null
        }

        const width = this.#parseMsnDimension(banner.width, window.innerWidth)
        const height = this.#parseMsnDimension(banner.height, window.innerHeight)
        if (width === null || height === null) {
            return null
        }

        const smallerSizes = sizes.filter((size) => size[0] <= width && size[1] <= height)
        if (smallerSizes.length === 0) {
            return null
        }

        let bestSize = smallerSizes[0]
        let bestArea = bestSize[0] * bestSize[1]

        smallerSizes.forEach((size) => {
            const area = size[0] * size[1]
            if (area > bestArea) {
                bestArea = area
                bestSize = size
            }
        })

        return `${position}:${bestSize[0]}x${bestSize[1]}`
    }

    // Advanced banners are validated as percent-only before they reach the bridge.
    #parseMsnDimension(value: string | undefined, screenSize: number): number | null {
        if (typeof value !== 'string' || !value.endsWith('%')) {
            return null
        }

        const percent = parseFloat(value)
        if (Number.isNaN(percent)) {
            return null
        }

        return Math.floor((screenSize * percent) / 100)
    }

    #resolveMsnPosition(banner: AdvancedBannerConfig): string | null {
        const hasTop = banner.top !== undefined
        const hasBottom = banner.bottom !== undefined
        const hasLeft = banner.left !== undefined
        const hasRight = banner.right !== undefined

        if (hasTop && hasLeft) {
            return 'topleft'
        }
        if (hasTop && hasRight) {
            return 'topright'
        }
        if (hasBottom && hasLeft) {
            return 'bottomleft'
        }
        if (hasBottom && hasRight) {
            return 'bottomright'
        }
        if (hasTop) {
            return 'top'
        }
        if (hasBottom) {
            return 'bottom'
        }
        if (hasLeft) {
            return 'left'
        }
        if (hasRight) {
            return 'right'
        }

        return null
    }

    #updatePlayerInfo(data: AnyRecord | null): void {
        if (data) {
            this._isPlayerAuthorized = true
            this._playerId = (data.playerId ?? data.publisherPlayerId) as string
            this._playerName = data.playerDisplayName as string
            this._playerExtra = data
            this.#isPaymentsSupported = (data.userAccountType as string).toLowerCase() === 'personal'
            // The player may sign in after init (via authorizePlayer or implicitly through payments);
            // enable cloud storage so the module migrates local data up and uses the cloud from now on.
            this._setPlatformStorageAvailable(true)
        }
    }
}

export default MsnPlatformBridge
