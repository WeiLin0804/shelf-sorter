/*
 * This file is part of Playgama Bridge.
 *
 * Playgama Bridge is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * Playgama Bridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Playgama Bridge. If not, see <https://www.gnu.org/licenses/>.
 */

import PlatformBridgeBase from './PlatformBridgeBase'
import { addJavaScript, waitFor } from '../utils'
import { ACTION_NAME } from '../constants'
import {
    PLATFORM_ID,
    PLATFORM_MESSAGE,
    type PlatformId,
} from '../modules/platform/constants'
import {
    INTERSTITIAL_STATE,
    REWARDED_STATE,
} from '../modules/advertisement/constants'

const SDK_URL = 'https://game-cdn.poki.com/scripts/v2/poki-sdk.js'

interface PokiSdk {
    init(): Promise<unknown>
    gameLoadingFinished(): void
    gameplayStart(): void
    gameplayStop(): void
    commercialBreak(onStart: () => void): Promise<unknown>
    rewardedBreak(onStart: () => void): Promise<boolean>
}

declare global {
    interface Window {
        PokiSDK?: PokiSdk
    }
}

class PokiPlatformBridge extends PlatformBridgeBase {
    // platform
    get platformId(): PlatformId {
        return PLATFORM_ID.POKI
    }

    get isPlatformExternalCallsSupported(): boolean {
        return false
    }

    // advertisement
    get isInterstitialSupported(): boolean {
        return true
    }

    get isRewardedSupported(): boolean {
        return true
    }

    // social
    get isPlatformExternalLinksAllowed(): boolean {
        return false
    }

    // clipboard
    get isClipboardSupported(): boolean {
        return false
    }

    initialize(): Promise<unknown> {
        if (this._isInitialized) {
            return Promise.resolve()
        }

        let promiseDecorator = this._getPromiseDecorator(ACTION_NAME.INITIALIZE)
        if (!promiseDecorator) {
            promiseDecorator = this._createPromiseDecorator(ACTION_NAME.INITIALIZE)

            addJavaScript(SDK_URL).then(() => {
                waitFor('PokiSDK', 'init').then(() => {
                    this._platformSdk = window.PokiSDK as PokiSdk;
                    (this._platformSdk as PokiSdk).init().then(() => {
                        this._isInitialized = true
                        this._resolvePromiseDecorator(ACTION_NAME.INITIALIZE)
                    })
                })
            })
        }

        return promiseDecorator.promise
    }

    // platform
    sendMessage(message?: unknown): Promise<unknown> {
        const sdk = this._platformSdk as PokiSdk
        switch (message) {
            case PLATFORM_MESSAGE.GAME_READY: {
                sdk.gameLoadingFinished()
                return Promise.resolve()
            }
            case PLATFORM_MESSAGE.GAMEPLAY_STARTED:
            case PLATFORM_MESSAGE.LEVEL_STARTED:
            case PLATFORM_MESSAGE.LEVEL_RESUMED: {
                sdk.gameplayStart()
                return Promise.resolve()
            }
            case PLATFORM_MESSAGE.GAMEPLAY_STOPPED:
            case PLATFORM_MESSAGE.LEVEL_PAUSED:
            case PLATFORM_MESSAGE.LEVEL_COMPLETED:
            case PLATFORM_MESSAGE.LEVEL_FAILED: {
                sdk.gameplayStop()
                return Promise.resolve()
            }
            default: {
                return super.sendMessage(message)
            }
        }
    }

    // advertisement
    showInterstitial(): void {
        let isInterstitialOpened = false;
        (this._platformSdk as PokiSdk).commercialBreak(() => {
            isInterstitialOpened = true
            this._setInterstitialState(INTERSTITIAL_STATE.OPENED)
        })
            .then(() => {
                if (isInterstitialOpened) {
                    this._setInterstitialState(INTERSTITIAL_STATE.CLOSED)
                } else {
                    this._showAdFailurePopup(false)
                }
            })
            .catch(() => {
                this._showAdFailurePopup(false)
            })
    }

    showRewarded(): void {
        let isRewardedOpened = false;
        (this._platformSdk as PokiSdk).rewardedBreak(() => {
            isRewardedOpened = true
            this._setRewardedState(REWARDED_STATE.OPENED)
        })
            .then((success) => {
                if (isRewardedOpened) {
                    if (success) {
                        this._setRewardedState(REWARDED_STATE.REWARDED)
                    }

                    this._setRewardedState(REWARDED_STATE.CLOSED)
                } else {
                    this._showAdFailurePopup(true)
                }
            })
            .catch(() => {
                this._showAdFailurePopup(true)
            })
    }
}

export default PokiPlatformBridge
