/*
 * This file is part of Playgama Bridge.
 *
 * Playgama Bridge is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * Playgama Bridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with Playgama Bridge. If not, see <https://www.gnu.org/licenses/>.
 */

import type { AnyRecord } from '../../utils'
import type { AdvertisementOptions } from '../../modules/advertisement/types'
import type { DailyRewardsConfig } from '../../modules/daily-rewards/types'
import type { TasksConfig } from '../../modules/tasks/types'
import type { AchievementMapping } from '../../modules/achievements/types'
import type { CrossPromoConfig } from '../../modules/cross-promo/types'
import type { LeaderboardMapping } from '../../modules/leaderboards'
import type { SocialConfig } from '../../modules/social/types'
import type { NotificationMapping } from '../../modules/notifications/types'
import type { DeviceConfig } from '../../modules/device'

export interface SaasFeatureConfig {
    platforms?: string[]
}

export interface SaasConfig {
    baseUrl?: string
    publicToken?: string
    // Per-feature SaaS configuration keyed by feature name.
    [feature: string]: SaasFeatureConfig | string | undefined
}

export interface GameConfig {
    adaptToSafeArea?: boolean
    [key: string]: unknown
}

// YouTube video preview shown in the bottom-right corner while the game is loading.
// `image` is a path to a thumbnail bundled with the game archive,
// `videoId` is the YouTube video id opened via ytgame.engagement.openYTContent.
export interface VideoPreview {
    image: string
    videoId: string
}

// Branded sound played once while the loading screen is visible.
// `url` is a path to an audio file bundled with the game archive (or a data URI).
export interface LoadingSoundConfig {
    url: string
}

// Single source of truth for the whole bridge configuration. Every config
// section is typed here so consumers read it through the config loader without
// per-site casts. The string index signature keeps platform-specific keys
// (devId, gameId, adSenseId, ...) accessible to the platform bridges.
export interface ConfigFileOptions extends AnyRecord {
    platforms?: Record<string, ConfigFileOptions>
    debug?: boolean
    forciblySetPlatformId?: string
    remoteConfigUrl?: string
    remoteConfigTimeout?: number
    remoteConfigTtl?: number
    sendAnalyticsEvents?: boolean
    disableLoadingLogo?: boolean
    showFullLoadingLogo?: boolean
    showLoadingText?: boolean
    loadingSound?: LoadingSoundConfig
    game?: GameConfig
    advertisement?: AdvertisementOptions
    dailyRewards?: DailyRewardsConfig
    tasks?: TasksConfig
    achievements?: AchievementMapping[]
    leaderboards?: LeaderboardMapping[]
    social?: SocialConfig
    notifications?: NotificationMapping[]
    disableAutoNotifications?: boolean
    device?: DeviceConfig
    crossPromo?: CrossPromoConfig
    saas?: SaasConfig
    payments?: Array<AnyRecord & { id: string }>
    videoPreviews?: VideoPreview[]
}
